#M3T1
#CTI110 - Hello World
#Brett Greiner
#11/6/2017
print('Hello World')
print('2+2')
print('10/3')
